/// \file WaitState.h
/// \brief WaitState class declaration
/// \author Robert Brede

#ifndef _WAIT_STATE_H_
#define _WAIT_STATE_H_

#include <string>

#include "BaseState.h"

//wait to be healed by healer
class WaitState : public State
{

private:
	std::string m_stateName = "WAIT";
protected:
public:
	void Start(AIAgent *_owner);
	State* Update(AIAgent *_owner);
	void End(AIAgent *_owner);

	std::string GetStateName()
	{
		return std::string("WAIT");
	}
};

#endif
