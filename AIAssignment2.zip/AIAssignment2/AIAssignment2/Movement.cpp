///  @file Movement.cpp
///  @brief Movement function definition

#include "Movement.h"

PositionCoord Translate(PositionCoord _currentPos, PositionCoord _targetPos)
{
	//moves the player/agent 2 pixels towards the target position
	PositionCoord returnPos = _currentPos;

	if (_currentPos.x < _targetPos.x)
	{
		returnPos.x+=2;
	}
	else if (_currentPos.x > _targetPos.x)
	{
		returnPos.x-=2;
	}

	if (_currentPos.y < _targetPos.y)
	{
		returnPos.y+=2;
	}
	else if (_currentPos.y > _targetPos.y)
	{
		returnPos.y-=2;
	}

	return returnPos;
}