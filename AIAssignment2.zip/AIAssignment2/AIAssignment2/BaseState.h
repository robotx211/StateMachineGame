/// \file BaseState.h
/// \brief State class declaration
/// \author Robert Brede

#ifndef _BASE_STATE_H_
#define _BASE_STATE_H_

#include <string>

class AIAgent;
class StateManager;

class State
{

private:
	std::string m_stateName = "BASE";
protected:
public:
	State();
	~State();

	virtual void Start(AIAgent *_owner);
	virtual State* Update(AIAgent *_owner);
	virtual void End(AIAgent *_owner);

	virtual std::string GetStateName()
	{
		return std::string("BASE");
	}


};

#endif