/// \file Enums.h
/// \brief enum AIType definition
/// \author Robert Brede

#ifndef _ENUMS_H_
#define _ENUMS_H_

//enum of agent classes
enum AIType
{
	KNIGHT,
	ARCHER,
	WIZARD,
	HEALER
};

#endif // _ENUMS_H_
