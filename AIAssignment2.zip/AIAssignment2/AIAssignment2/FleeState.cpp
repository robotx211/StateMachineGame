///  @file FleeState.cpp
///  @brief FleeState class definition

#include <iostream>
#include <cmath>

#include "FleeState.h"
#include "WaitState.h"
#include "DieState.h"
#include "IdleState.h"

#include "Node.h"
#include "AIAgent.h"
#include "Scene.h"

/*
FLEE
in:	ATTACK
	PURSUE
out:WAIT
	DIE
*/

void FleeState::Start(AIAgent *_owner)
{
	//if healer is alive
		//gen path to healer, avoiding player
	//else
		//gen path to safe point
	_owner->GenPathToHealer();

	std::cout << "FLEE START" << std::endl;
}

State* FleeState::Update(AIAgent *_owner)
{
	//if next to healer
		//move to wait state
	//else if reached path goal
		//move to wait state
	//else if path no longer valid (node on path has become an obstacle)
		//gen new path
	//else
		//move along path

	if (_owner->GetHealthPercent() <= 0.0f)
	{
		return new DieState;
	}

	//if there is a healer to go to
	if (_owner->GetTargetHealer() != nullptr)
	{
		//if healer in heal range
		if (std::abs(_owner->GetWorldPos().x - _owner->GetTargetHealer()->GetWorldPos().x) <= 1 && std::abs(_owner->GetWorldPos().y - _owner->GetTargetHealer()->GetWorldPos().y) <= 1)
		{
			return new WaitState;
		}
	}
	
	_owner->GenPathToHealer();

	if (_owner->CheckIfNoPath() == true)
	{
		return new IdleState;
	}

	//else
	while (_owner->CheckIfAtWaypoint() != true)
	{
		_owner->Move();
		_owner->DrawAll();
	}


	_owner->SetTurnStatus(true);


	std::cout << "FLEE" << std::endl;
	return this;
}

void FleeState::End(AIAgent *_owner)
{
	//nothing to do for end
	std::cout << "FLEE END" << std::endl;
}