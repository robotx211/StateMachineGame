///  @file Scene.cpp
///  @brief Scene class definition

#include <SDL2\SDL.h>

#include <vector>
#include <iostream>
#include <algorithm>
#include <string>

#include "Scene.h"
#include "MapLayouts.h"
#include "Node.h"
#include "PFAlgorithms.h"
#include "Player.h"
#include "AIAgent.h"

Scene::Scene()
{
	//should not be used
}

bool sortFunction (AIAgent *_agent1, AIAgent *_agent2)
{
	return (_agent1->GetClass() < _agent2->GetClass());
}

Scene::Scene(SDL_Window *_window, SDL_Renderer *_renderer)
{
	m_window = _window;
	m_renderer = _renderer;
	m_resourceMan = new ResourceManager(m_renderer);
	m_nMap = new NodeManager(30, 30);

	m_mapLayout = &mapLayout;
	m_agentSpawns = &agentSpawns;

	m_player = new Player(m_resourceMan, 0, 0);

	LoadMap();

	//sort agents by enum AIType, so order becomes knights, archers, mages, healers
	//this means stronger classes get movement priority, and healers go last, so agents can be healed after they moved on their turn
	std::sort(m_AIAgents.begin(), m_AIAgents.end(), sortFunction);
}

Scene::~Scene()
{
}

void Scene::PlayerTurn()
{
	//runs 1 player turn
	//player can move, by selecting a node to move to, and then attack, by selecting a node to attack, and which attack to use
	m_playerMoved = false;
	std::cout << "~~Player Turn~~" << std::endl;
	m_player->AddMana(2);
	Draw();
	std::cout << "Choose move direction" << std::endl;
	PlayerSelectNode();
	while (m_player->CheckIfAtWaypoint() != true)
	{
		m_playerMoved = true;
		m_player->Move();
		Draw();
	}
	std::cout << "Attack" << std::endl;
	PlayerAttack();

	//update node map obstructions
	SetObstructions();
}

void Scene::EnemyTurn()
{
	//runs 1 turn for each enemy agent
	//each agent gets 1 update call each turn
	//if the agent ends a turn in the die state, they stop being drawn
	std::string dieTest = "DIE";
	std::cout << "~~Enemy Turn~~" << std::endl;
	for (int i = 0; i < m_AIAgents.size(); i++)
	{
		Draw();
		std::cout << "Enemy: " << i << ", " << m_AIAgents.at(i)->GetClass() << std::endl;
		m_AIAgents.at(i)->SetTurnStatus(false);
		while (m_AIAgents.at(i)->CheckTurnStatus() == false)
		{
			m_AIAgents.at(i)->Update();
			if (m_AIAgents.at(i)->GetState()->GetStateName().compare(dieTest) != 0)
			{
				m_AIAgents.at(i)->Draw(m_renderer);
			}
		}
	}

	//delete dead AI
	for (int i = m_AIAgents.size() - 1; i >= 0; i--)
	{
		if (m_AIAgents.at(i)->GetState()->GetStateName().compare(dieTest) == 0)
		{
			m_AIAgents.erase(m_AIAgents.begin() + i);
		}
	}

	SetObstructions();
}

void Scene::Draw()
{
	//draw map, player and enemies
	SDL_RenderClear(m_renderer);
	m_nMap->DrawNMap(m_renderer);
	for (int i = 0; i < m_AIAgents.size(); i++)
	{
		m_AIAgents.at(i)->Draw(m_renderer);
	}
	m_player->Draw(m_window, m_renderer);
	SDL_RenderPresent(m_renderer);

	SDL_Delay(1000/120);
}

void Scene::LoadMap()
{
	//load map layout
	std::cout << "m_mapLayout->size() = " << m_mapLayout->size() << std::endl;
	std::cout << "m_mapLayout->at(0).size() = " << m_mapLayout->at(0).size() << std::endl;


	for (int y = 0; y < m_mapLayout->size(); y++)
	{
		for (int x = 0; x < m_mapLayout->at(y).size(); x++)
		{
			switch (m_mapLayout->at(y).at(x))
			{
			case 0:	m_nMap->m_NodeMap.at(x).at(y)->SetValues({ 111,255,114 }, { 111,255,114 }, x, y, false); //0 = grass
				break;
			case 1:	m_nMap->m_NodeMap.at(x).at(y)->SetValues({ 125,161,142 }, { 125,161,142 }, x, y, false); //1 = path
				break;
			case 2:	m_nMap->m_NodeMap.at(x).at(y)->SetValues({ 155,84,46 }, { 155,84,46 }, x, y, true); //2 = wall
				break;
			}
		}
	}

	//load enemy and player positions
	for (int y = 0; y < m_agentSpawns->size(); y++)
	{
		for (int x = 0; x < m_agentSpawns->at(y).size(); x++)
		{
			switch (m_agentSpawns->at(y).at(x))
			{
			case 1:	m_AIAgents.push_back(new AIAgent(AIType::KNIGHT, m_resourceMan, x, y, this)); //1 = KNIGHT
				break;
			case 2:	m_AIAgents.push_back(new AIAgent(AIType::ARCHER, m_resourceMan, x, y, this)); //2 = ARCHER
				break;
			case 3:	m_AIAgents.push_back(new AIAgent(AIType::WIZARD, m_resourceMan, x, y, this)); //3 = WIZARD
				break;
			case 4:	m_AIAgents.push_back(new AIAgent(AIType::HEALER, m_resourceMan, x, y, this)); //4 = HEALER
				break;
			case 5:	m_player->SetPosition(x, y); //5 = set player position, means there is only 1 player
				break;
			}
		}

	}



}

void Scene:: PlayerSelectNode()
{
	//player selects node for movement
	int maxX = m_nMap->m_NodeMap.size() - 1;
	int maxY = m_nMap->m_NodeMap.at(0).size() - 1;
	PositionCoord temp;
	SDL_Event ev;
	bool breakout = false;


	//wait for input
	//if space, set waypoint = current position
	//if other movement (using numpad), set waypoint to desired 

	while (SDL_PollEvent(&ev) != 0)
	{
		//clears the event buffer so only the newest keypress is registered
	}

	while (breakout == false)
	{
		temp = m_player->GetWorldPos();
		while (SDL_PollEvent(&ev) != 0)
		{
			if (ev.type == SDL_KEYDOWN && breakout == false)
			{
				if (ev.key.keysym.sym == SDLK_SPACE)
				{
					m_player->SetWayPoint(temp);
					breakout = true;
				}
				else
				{
					/*
					 && m_player->GetWorldPos().y > 0 //up
					 && m_player->GetWorldPos().y < maxY //down
					 && m_player->GetWorldPos().x < maxX //right
					 && m_player->GetWorldPos().x > 0 //left

					temp.y--;//up
					temp.y++;//down
					temp.x++;//right
					temp.x--;//left
					*/

					if (ev.key.keysym.sym == SDLK_KP_8
						&& m_player->GetWorldPos().y > 0)
					{
						temp.y--;//up
						breakout = true;
					}
					else if (ev.key.keysym.sym == SDLK_KP_9
						&& m_player->GetWorldPos().y > 0
						&& m_player->GetWorldPos().x < maxX)
					{
						temp.y--;//up
						temp.x++;//right
						breakout = true;
					}
					else if (ev.key.keysym.sym == SDLK_KP_6
						&& m_player->GetWorldPos().x < maxX)
					{
						temp.x++;//right
						breakout = true;
					}
					else if (ev.key.keysym.sym == SDLK_KP_3
						&& m_player->GetWorldPos().y < maxY
						&& m_player->GetWorldPos().x < maxX)
					{
						temp.y++;//down
						temp.x++;//right
						breakout = true;
					}
					else if (ev.key.keysym.sym == SDLK_KP_2
						&& m_player->GetWorldPos().y < maxY)
					{
						temp.y++;//down
						breakout = true;
					}
					else if (ev.key.keysym.sym == SDLK_KP_1
						&& m_player->GetWorldPos().y < maxY
						&& m_player->GetWorldPos().x > 0)
					{
						temp.y++;//down
						temp.x--;//left
						breakout = true;
					}
					else if (ev.key.keysym.sym == SDLK_KP_4
						&& m_player->GetWorldPos().x > 0)
					{
						temp.x--;//left
						breakout = true;
					}
					else if (ev.key.keysym.sym == SDLK_KP_7
						&& m_player->GetWorldPos().y > 0
						&& m_player->GetWorldPos().x > 0)
					{
						temp.y--;//up
						temp.x--;//left
						breakout = true;
					}

					if (m_nMap->m_NodeMap.at(temp.x).at(temp.y)->m_isObject == true || m_nMap->m_NodeMap.at(temp.x).at(temp.y)->m_isObstructed == true)
					{
						breakout = false;
					}
				}
			}
		}
		
	}
	m_player->SetWayPoint(temp);
}

void Scene::PlayerAttack()
{
	//player selects attack type and then direction of attack (if needed)
	int maxX = m_nMap->m_NodeMap.size() - 1;
	int maxY = m_nMap->m_NodeMap.at(0).size() - 1;
	PositionCoord temp; //position of attack

	PositionCoord temp2; //postions of secondary attacks
	PositionCoord temp3; 

	SDL_Event ev;
	bool breakout = false;

	int attackType; //0 = no attack, 1 = normal attack, 2 = swipe attack, 3 = line attack, 4 = AOE attack, 5 = healself


	//wait for input
	//if space, set waypoint = current position
	//if up/down/left/right, set waypoint to desired 

	while (SDL_PollEvent(&ev) != 0)
	{
		//clears the event buffer so only the newest keypress is registered
	}

	std::cout << "\tChoose attack type" << std::endl;


	//select attack using space, q, w, e ,r and t
	//if player doesn't have enough mana to use the attack, another attack must be chosen
	while (breakout == false)
	{
		while (SDL_PollEvent(&ev) != 0)
		{
			if (ev.type == SDL_KEYDOWN && breakout == false)
			{
				switch (ev.key.keysym.sym)
				{
				case SDLK_SPACE: //no attack = 0 mana
				{
					attackType = 0;
					breakout = true;
					break;
				}
				case SDLK_q: //normal attack = 0 mana
				{
					attackType = 1;
					std::cout << "Normal attack selected" << std::endl;
					breakout = true;
					break;
				}
				case SDLK_w: //swipe attack = 20 mana
				{
					attackType = 2;
					if (m_player->GetMana() < 20)
					{
						std::cout << "Insufficient Mana" << std::endl;
					}
					else
					{
						std::cout << "Swipe attack selected" << std::endl;
						breakout = true;
					}

					break;
				}
				case SDLK_e: //line attack = 20 mana
				{
					attackType = 3;
					if (m_player->GetMana() < 20)
					{
						std::cout << "Insufficient Mana" << std::endl;
					}
					else
					{
						std::cout << "Line attack selected" << std::endl;
						breakout = true;
					}
					break;
				}
				case SDLK_r: //AOE attack = 50 mana
				{
					attackType = 4;
					if (m_player->GetMana() < 50)
					{
						std::cout << "Insufficient Mana" << std::endl;
					}
					else
					{
						std::cout << "AOE attack selected" << std::endl;
						breakout = true;
					}
					break;
				}
				case SDLK_t: //healself = 50 mana
				{
					attackType = 5;
					if (m_player->GetMana() < 50)
					{
						std::cout << "Insufficient Mana" << std::endl;
					}
					else
					{
						std::cout << "Heal self selected" << std::endl;
						breakout = true;
					}
					break;
				}
				}
			}
		}
	}

	if (attackType == 0)
	{
		//do nothing
		return;
	}
	else if (attackType == 5)
	{
		//heal self
		m_player->RemoveMana(50);
		m_player->AddHealth(20);
		return;
	}
	else if (attackType == 4)
	{
		//skip attack aiming, as it is AOE
	}
	else
	{
		breakout = false; //used to select attack direction
	}
	

	while (SDL_PollEvent(&ev) != 0)
	{
		//clears the event buffer so only the newest keypress is registered
	}

	if (attackType != 4)
	{
		std::cout << "\tChoose direction of attack" << std::endl;
	}

	while (breakout == false)
	{
		temp = m_player->GetWorldPos();
		while (SDL_PollEvent(&ev) != 0)
		{
			if (ev.type == SDL_KEYDOWN && breakout == false)
			{
				/*
				&& m_player->GetWorldPos().y > 0 //up
				&& m_player->GetWorldPos().y < maxY //down
				&& m_player->GetWorldPos().x < maxX //right
				&& m_player->GetWorldPos().x > 0 //left

				temp.y--;//up
				temp.y++;//down
				temp.x++;//right
				temp.x--;//left
				*/

				if (ev.key.keysym.sym == SDLK_KP_8)
				{
					temp.y--;//up

					temp2 = temp;
					temp3 = temp;

					if (attackType == 2)
					{
						temp2.x--;//left
						temp3.x++;//right
					}
					else if (attackType == 3)
					{
						temp2.y--;//up 1
						temp3.y -= 2;//up 2
					}

					breakout = true;
				}
				else if (ev.key.keysym.sym == SDLK_KP_9)
				{
					temp.y--;//up
					temp.x++;//right

					temp2 = temp;
					temp3 = temp;

					if (attackType == 2)
					{
						temp2.x--;//left
						temp3.y++;//down
					}
					else if (attackType == 3)
					{
						temp2.y--;//up 2
						temp2.x++;//right 2
						temp3.y -= 2;//up 2
						temp3.x += 2;//right 2
					}

					breakout = true;
				}
				else if (ev.key.keysym.sym == SDLK_KP_6)
				{
					temp.x++;//right
					
					temp2 = temp;
					temp3 = temp;

					if (attackType == 2)
					{
						temp2.y--;//up
						temp3.y++;//down
					}
					else if (attackType == 3)
					{
						temp2.x++;//right 1
						temp3.x += 2;//right 2
					}

					breakout = true;
				}
				else if (ev.key.keysym.sym == SDLK_KP_3)
				{
					temp.y++;//down
					temp.x++;//right

					temp2 = temp;
					temp3 = temp;

					if (attackType == 2)
					{
						temp2.y--;//up
						temp3.x--;//left
					}
					else if (attackType == 3)
					{
						temp2.y++;//down 2
						temp2.x++;//right 2
						temp3.y += 2;//down 3
						temp3.x += 2;//right 3
					}

					breakout = true;
				}
				else if (ev.key.keysym.sym == SDLK_KP_2)
				{
					temp.y++;//down

					temp2 = temp;
					temp3 = temp;

					if (attackType == 2)
					{
						temp2.x++;//right
						temp3.x--;//left
					}
					else if (attackType == 3)
					{
						temp2.y++;//down 2
						temp3.y += 2;//down 3
					}

					breakout = true;
				}
				else if (ev.key.keysym.sym == SDLK_KP_1)
				{
					temp.y++;//down
					temp.x--;//left

					temp2 = temp;
					temp3 = temp;

					if (attackType == 2)
					{
						temp2.x++;//right
						temp3.y--;//up
					}
					else if (attackType == 3)
					{
						temp2.y++;//down 2
						temp2.x--;//left 2
						temp3.y += 2;//down 3
						temp3.x -= 2;//left 3
					}

					breakout = true;
				}
				else if (ev.key.keysym.sym == SDLK_KP_4)
				{
					temp.x--;//left

					temp2 = temp;
					temp3 = temp;

					if (attackType == 2)
					{
						temp2.y++;//down
						temp3.y--;//up
					}
					else if (attackType == 3)
					{
						temp2.x--;//left 2
						temp3.x -= 2;//left 3
					}

					breakout = true;
				}
				else if (ev.key.keysym.sym == SDLK_KP_7)
				{
					temp.y--;//up
					temp.x--;//left

					temp2 = temp;
					temp3 = temp;

					if (attackType == 2)
					{
						temp2.y++;//down
						temp3.x++;//right
					}
					else if (attackType == 3)
					{
						temp2.y--;//up 2
						temp2.x--;//left 2
						temp3.y -= 2;//up 3
						temp3.x -= 2;//left 3
					}

					breakout = true;
				}
			}
		}
	}

	if (attackType == 1)
	{
		for each (AIAgent* i in m_AIAgents) //deal 4 dmg in selected direction
		{
			if (i->GetWorldPos().x == temp.x && i->GetWorldPos().y == temp.y)
			{
				i->DealDamage(4);
			}
		}
	}
	else if (attackType == 2)
	{
		for each (AIAgent* i in m_AIAgents) //deal 4 dmg in selected direction, and 2 to each side (nearest player)
		{
			if (i->GetWorldPos().x == temp.x && i->GetWorldPos().y == temp.y)
			{
				i->DealDamage(4);
			}
			if (i->GetWorldPos().x == temp2.x && i->GetWorldPos().y == temp2.y)
			{
				i->DealDamage(2);
			}
			if (i->GetWorldPos().x == temp3.x && i->GetWorldPos().y == temp3.y)
			{
				i->DealDamage(2);
			}
		}
		m_player->RemoveMana(20);
	}
	else if (attackType == 3)
	{
		for each (AIAgent* i in m_AIAgents) //deal 4 dmg in selected direction, and 2 to each after it (in a line of 3)
		{
			if (i->GetWorldPos().x == temp.x && i->GetWorldPos().y == temp.y)
			{
				i->DealDamage(4);
			}
			if (i->GetWorldPos().x == temp2.x && i->GetWorldPos().y == temp2.y)
			{
				i->DealDamage(2);
			}
			if (i->GetWorldPos().x == temp3.x && i->GetWorldPos().y == temp3.y)
			{
				i->DealDamage(2);
			}
		}
		m_player->RemoveMana(20);
	}
	else if (attackType == 4)
	{
		for each (AIAgent* i in m_AIAgents) //deal 2 dmg in all directions from player
		{
			for (int x = -1; x <= 1; x++)
			{
				for (int y = -1; y <= 1; y++)
				{
					if (x == 0 && y == 0)
					{
					}
					else if (i->GetWorldPos().x == m_player->GetWorldPos().x + x && i->GetWorldPos().y == m_player->GetWorldPos().y + y)
					{
						i->DealDamage(2);
					}	
				}
			}
		}
		m_player->RemoveMana(50);
	}


}

PositionCoord Scene::GetPlayerPos()
{
	return m_player->GetWorldPos();
}

void Scene::DamagePlayer(int _dmg)
{
	m_player->DealDamage(_dmg);
}

void Scene::HealEnemies(PositionCoord _source, int _healing)
{
	//heals all enemies around healing source
	for each (AIAgent* i in m_AIAgents)
	{
		if ( (i->GetWorldPos().x + 1 == _source.x || i->GetWorldPos().x == _source.x || i->GetWorldPos().x - 1 == _source.x) &&
			 (i->GetWorldPos().y + 1 == _source.y || i->GetWorldPos().y == _source.y || i->GetWorldPos().y - 1 == _source.y) &&
			 !(i->GetWorldPos().x == _source.x && i->GetWorldPos().y == _source.y) )
		{
			i->AddHealth(_healing);
		}
	}
}

bool Scene::CheckIfPlayerMoved()
{
	return m_playerMoved;
}

void Scene::GenPathToPlayer(AIAgent *_start)
{
	//generates a path from the start to the player
	//if no valid path, returns a path to the start
	_start->SetPath(m_pathingManager.GenAStarPath(m_nMap->m_NodeMap.at(_start->GetWorldPos().x).at(_start->GetWorldPos().y), m_nMap->m_NodeMap.at(m_player->GetWorldPos().x).at(m_player->GetWorldPos().y), m_nMap));
}

AIAgent* Scene::GenPathToNearestHealer(AIAgent *_start)
{
	//generates a path from the start to the nearest healer
	//if no valid path, returns a path to the start
	//function returns a pointer to the target healer
	AIAgent *nearestHealer = nullptr;
	std::vector<Node*> currentPath;
	std::vector<Node*> bestPath;

	for each (AIAgent* i in m_AIAgents)
	{
		if (i->GetClass() == AIType::HEALER)
		{
			currentPath = m_pathingManager.GenAStarPath(m_nMap->m_NodeMap.at(_start->GetWorldPos().x).at(_start->GetWorldPos().y), m_nMap->m_NodeMap.at(i->GetWorldPos().x).at(i->GetWorldPos().y), m_nMap);
			if (bestPath.size() == 0 || currentPath.size() < bestPath.size())
			{
				bestPath = currentPath;
				nearestHealer = i;
			}
		}
	}
	if (nearestHealer == nullptr)
	{
		bestPath.push_back(m_nMap->m_NodeMap.at(_start->GetWorldPos().x).at(_start->GetWorldPos().y));
	}

	_start->SetPath(bestPath);

	return nearestHealer; //if no healer left, return nullptr
}

void Scene::SetObstructions()
{
	//sets each node on the nodemap to be an obstruction, if the player or an agent is on it
	for (int x = 0; x < m_nMap->m_NodeMap.size(); x++)
	{
		for (int y = 0; y < m_nMap->m_NodeMap.at(x).size(); y++)
		{
			m_nMap->m_NodeMap.at(x).at(y)->m_isObstructed = false;
		}
	}

	for each (AIAgent* i in m_AIAgents)
	{
		m_nMap->m_NodeMap.at(i->GetWorldPos().x).at(i->GetWorldPos().y)->m_isObstructed = true;
	}

	m_nMap->m_NodeMap.at(m_player->GetWorldPos().x).at(m_player->GetWorldPos().y)->m_isObstructed = true;
}


