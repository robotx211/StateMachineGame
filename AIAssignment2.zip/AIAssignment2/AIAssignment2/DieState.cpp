///  @file DieState.cpp
///  @brief DieState class definition

#include <iostream>

#include "BaseState.h"
#include "DieState.h"

#include "AIAgent.h"

/*
DIE
in:	PURSUE
	ATTACK
	FLEE
	WAIT
out:
*/

void DieState::Start(AIAgent *_owner)
{
	//play death anim + sound
	std::cout << "DIE START" << std::endl;
}

State* DieState::Update(AIAgent *_owner)
{
	//nothing, stuck in die state, until agent is deleted


	_owner->SetTurnStatus(true);


	std::cout << "DIE" << std::endl;
	return this;
}

void DieState::End(AIAgent *_owner)
{
	//call for agent to be deleted
}