///  @file main.cpp
///  @brief main function and program start point

#include <iostream>
#include <SDL2\SDL.h>

#include "AIAgent.h"
#include "NodeManager.h"
#include "StateManager.h"
#include "ResourceManager.h"
#include "Scene.h"

#undef main

int main()
{
	SDL_Init(SDL_INIT_EVERYTHING);
	SDL_Window *window = nullptr;
	SDL_Renderer *renderer = nullptr;

	window = SDL_CreateWindow("PathfindingTest", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 900, 900, NULL);
	renderer = SDL_CreateRenderer(window, -1, NULL);

	Scene *mainScene = new Scene(window, renderer);
	bool breakout = false;

	//keep running player then enemy turn, no end game so game continues to run until quit
	while (breakout == false)
	{
		mainScene->PlayerTurn();
		mainScene->EnemyTurn();
	}

	return 0;
}