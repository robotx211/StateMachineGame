///  @file HealerIdle.cpp
///  @brief HealerIdleState class definition

#include <iostream>
#include <cmath>

#include "BaseState.h"
#include "HealerIdle.h"
#include "PursueState.h"
#include "DieState.h"

#include "AIAgent.h"


/*
IDLE
in:	HEALER_FLEE
out:HEALER_FLEE
	DIE
*/

void HealerIdleState::Start(AIAgent *_owner)
{
	//nothing to do for start
	std::cout << "HEALER_IDLE START" << std::endl;
}

State* HealerIdleState::Update(AIAgent *_owner)
{
	//if player too close
		//go to flee
	//else
		//heal
	
	if (_owner->GetHealthPercent() <= 0.0f)
	{
		return new DieState;
	}

	if ((std::abs(_owner->GetWorldPos().x - _owner->GetPlayerPos().x) + std::abs(_owner->GetWorldPos().y - _owner->GetPlayerPos().y)) <= 5)
	{
		//return new HealerFleeState;
	}

	_owner->HealEnemies();

	_owner->SetTurnStatus(true);

	std::cout << "HEALER_IDLE" << std::endl;
	return this;

}

void HealerIdleState::End(AIAgent *_owner)
{
	//nothing to do for end
	std::cout << "HEALER_IDLE END" << std::endl;
}