/// \file AttackState.h
/// \brief AttackState class declaration
/// \author Robert Brede

#ifndef _ATTACK_STATE_H_
#define _ATTACK_STATE_H_

#include <string>

#include "BaseState.h"

//attack player
class AttackState : public State
{

private:
	std::string m_stateName = "ATTACK";
protected:
public:
	void Start(AIAgent *_owner);
	State* Update(AIAgent *_owner);
	void End(AIAgent *_owner);

	std::string GetStateName() {
		return std::string("ATTACK");
	}
};

#endif
