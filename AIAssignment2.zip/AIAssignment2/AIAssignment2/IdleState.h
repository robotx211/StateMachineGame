/// \file IdleState.h
/// \brief IdleState class declaration
/// \author Robert Brede

#ifndef _IDLE_STATE_H_
#define _IDLE_STATE_H_

#include <string>

#include "BaseState.h"

//stand still and wait
class IdleState : public State
{

private:
	std::string m_stateName = "IDLE";
protected:
public:
	void Start(AIAgent *_owner);
	State* Update(AIAgent *_owner);	void End(AIAgent *_owner);

	std::string GetStateName() {
		return std::string("IDLE");
	}
};

#endif
