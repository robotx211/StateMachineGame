///  @file AIAgent.cpp
///  @brief AiAgent class definition

#include <iostream>
#include <SDL2\SDL.h>

#include "Enums.h"
#include "AIAgent.h"
#include "IdleState.h"
#include "ResourceManager.h"
#include "StateManager.h"
#include "Movement.h"
#include "PositionCoord.h"


AIAgent::AIAgent(AIType _class, ResourceManager *_resourceMan, int _posX, int _posY, Scene *_scene)
{
	m_class = _class;

	m_nMapPos.x = _posX;
	m_nMapPos.y = _posY;

	m_screenPos.x = _posX * 30;
	m_screenPos.y = _posY * 30;

	m_wayPoint = m_screenPos;

	m_sprite = _resourceMan->returnSprite(m_class);
	m_stateMan = new StateManager(this);

	m_ownerScene = _scene;

	if (_class == AIType::KNIGHT)
	{
		m_maxHealth = 20;
		m_attackDamage = 4;
	}
	else if (_class == AIType::ARCHER)
	{
		m_maxHealth = 10;
		m_attackDamage = 2;
	}
	else if (_class == AIType::HEALER)
	{
		m_maxHealth = 16;
		m_attackDamage = 0;
	}
	else if (_class == AIType::WIZARD)
	{
		m_maxHealth = 6;
		m_attackDamage = 4;
	}

	m_health = m_maxHealth;
}

AIAgent::~AIAgent()
{
}

AIType AIAgent::GetClass()
{
	return m_class;
}

PositionCoord AIAgent::GetWorldPos()
{
	return m_nMapPos;
}

float AIAgent::GetHealthPercent()
{
	return ((float)m_health/ (float)m_maxHealth) * 100;
}

void AIAgent::SetPath(std::vector<Node*> _path)
{
	m_path = _path;
	m_pathPosition = 0;
}

AIAgent* AIAgent::GetTargetHealer()
{
	return m_targetHealer;
}

SDL_Renderer* AIAgent::GetRenderer()
{
	return m_ownerScene->GetRenderer();
}

void AIAgent::DrawAll()
{
	m_ownerScene->Draw();
}

void AIAgent::Update()
{
	//run state manager top/current state update
	m_stateMan->Update();
}

void AIAgent::Draw(SDL_Renderer *_renderer)
{
	//draw using sprite
	SDL_Rect temp = { m_screenPos.x, m_screenPos.y, 30, 30 };
	SDL_RenderCopy(_renderer, m_sprite, NULL, &temp);

	//draw health bar
	SDL_SetRenderDrawColor(_renderer, 0, 0, 0, 0);
	temp = { m_screenPos.x + (((30 - m_maxHealth) / 2) - 1), m_screenPos.y + 22, (m_maxHealth + 2), 4};
	SDL_RenderDrawRect(_renderer, &temp);

	SDL_SetRenderDrawColor(_renderer, 255, 0, 0, 0);
	temp = { m_screenPos.x + (30 - m_maxHealth) / 2, m_screenPos.y + 23, m_maxHealth, 2 };
	SDL_RenderDrawRect(_renderer, &temp);

	if (m_health > 0)
	{
		SDL_SetRenderDrawColor(_renderer, 0, 255, 0, 0);
		temp = { m_screenPos.x + (30 - m_maxHealth) / 2, m_screenPos.y + 23, m_health, 2};
		SDL_RenderDrawRect(_renderer, &temp);
	}
}

void AIAgent::Move()
{
	//move from starting position to waypoint, then update obstructions on node map
	PositionCoord screenSpaceWaypoint;
	screenSpaceWaypoint.x = m_wayPoint.x * 30;
	screenSpaceWaypoint.y = m_wayPoint.y * 30;

	m_screenPos = Translate(m_screenPos, screenSpaceWaypoint);

	if (m_screenPos.x == screenSpaceWaypoint.x && m_screenPos.y == screenSpaceWaypoint.y)
	{
		m_nMapPos = m_wayPoint;
		m_ownerScene->SetObstructions();
	}
	
}

bool AIAgent::CheckIfPlayerMoved()
{
	return m_ownerScene->CheckIfPlayerMoved();
}

void AIAgent::GenPathToPlayer()
{
	//generate path to player, reset path position and update waypoint
	m_ownerScene->GenPathToPlayer(this);
	m_pathPosition = 0;
	m_wayPoint.x = m_path.at(m_pathPosition)->m_posX;
	m_wayPoint.y = m_path.at(m_pathPosition)->m_posY;
}

void AIAgent::GenPathToHealer()
{
	//generate path to healer, set target healer, reset path position and update waypoint
	m_targetHealer = m_ownerScene->GenPathToNearestHealer(this);
	m_pathPosition = 0;
	m_wayPoint.x = m_path.at(m_pathPosition)->m_posX;
	m_wayPoint.y = m_path.at(m_pathPosition)->m_posY;
}

PositionCoord AIAgent::GetPlayerPos()
{
	return m_ownerScene->GetPlayerPos();
}

bool AIAgent::CheckIfAtWaypoint()
{
	//check if at current waypoint
	if (m_screenPos.x == m_wayPoint.x * 30 && m_screenPos.y == m_wayPoint.y * 30)
	{
		m_pathPosition++;
		m_wayPoint.x = m_path.at(m_pathPosition)->m_posX;
		m_wayPoint.y = m_path.at(m_pathPosition)->m_posY;
		return true;
	}
	else
	{
		return false;
	}
}

bool AIAgent::CheckIfPathIsValid()
{
	//check if path is still valid
	for each (Node* i in m_path)
	{
		if (i->m_isObject == true || i->m_isObstructed == true)
		{
			return false;
		}
	}
	return true;
}

bool AIAgent::CheckIfNoPath()
{
	//check if there is not path (if path is to agent position)
	if (m_nMapPos.x == m_path.at(0)->m_posX && m_nMapPos.y == m_path.at(0)->m_posY)
	{
		return true;
	}
	return false;
}

void AIAgent::AttackPlayer()
{
	m_ownerScene->DamagePlayer(m_attackDamage);
}

void AIAgent::AddHealth(int _healAmount)
{
	m_health += _healAmount;
	if (m_health > m_maxHealth)
	{
		m_health = m_maxHealth;
	}
}

void AIAgent::HealEnemies()
{
	m_ownerScene->HealEnemies(GetWorldPos(), 2);
}

