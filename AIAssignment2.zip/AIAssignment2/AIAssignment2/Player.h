/// \file Player.h
/// \brief Player class declaration
/// \author Robert Brede

#ifndef _PLAYER_H_
#define _PLAYER_H_

#include <SDL2\SDL.h>
#include <SDL2\SDL_image.h>
#include <iostream>

#include "ResourceManager.h"
#include "NodeManager.h"

class ResourceManager;

class Player
{
private:
	PositionCoord m_nMapPos; //world space
	PositionCoord m_screenPos; //screen space
	SDL_Texture *m_sprite;

	PositionCoord m_wayPoint; //world space

	int m_health;
	int m_maxHealth;

	int m_mana;
	int m_maxMana;
protected:
public:
	Player(ResourceManager *_resourceMan, int _posX, int _posY);
	~Player();

	PositionCoord GetWorldPos();
	void SetPosition(int _posX, int _posY);

	void SetWayPoint(PositionCoord _waypoint);
	bool CheckIfAtWaypoint();

	void Update();
	void Draw(SDL_Window *_window, SDL_Renderer *_renderer);

	//different attacks
	//attacks to multiples of 2 dmg (makes the helath bars more acurate

	int GetHealth()
	{
		return m_health;
	}
	int GetMana()
	{
		return m_mana;
	}

	void DealDamage(int _dmg)
	{
		if (m_health > 0)
			m_health -= _dmg;
	}
	void RemoveMana(int _cost)
	{
		m_mana -= _cost;
	}
	void AddHealth(int _heal)
	{
		m_health += _heal;
		if (m_health > m_maxHealth)
		{
			m_health = m_maxHealth;
		}
	}
	void AddMana(int _mana)
	{
		m_mana += _mana;
		if (m_mana > m_maxMana)
		{
			m_mana = m_maxMana;
		}
	}

	
	void Move();

	void WriteData()
	{
		system("cls");

		std::cout << "nMap Pos: ";
		m_nMapPos.WritePosition();
		std::cout << std::endl;
		std::cout << "Screenspace Pos: ";
		m_screenPos.WritePosition();
		std::cout << std::endl;
		std::cout << "nMap Waypoint: ";
		m_wayPoint.WritePosition();
		std::cout << std::endl;
	}
};

#endif // !_PLAYER_H_
