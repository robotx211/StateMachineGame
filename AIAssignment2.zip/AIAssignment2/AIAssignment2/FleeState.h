/// \file FleeState.h
/// \brief FleeState class declaration
/// \author Robert Brede

#ifndef _FLEE_STATE_H_
#define _FLEE_STATE_H_

#include <string>

#include "BaseState.h"

//run from player to healer, or if no healer, run to safe zone
class FleeState : public State
{

private:
	std::string m_stateName = "FLEE";
protected:
public:
	void Start(AIAgent *_owner);
	State* Update(AIAgent *_owner);	void End(AIAgent *_owner);

	std::string GetStateName() {
		return std::string("FLEE");
	}
};

#endif
