///  @file StateManager.cpp
///  @brief StateManager class definition

#include <stack>

#include "StateManager.h"
#include "BaseState.h"
#include "IdleState.h"
#include "HealerIdle.h"
#include "AIAgent.h"

StateManager::StateManager(AIAgent *_owner)
{
	m_ownerAgent = _owner;
	if ( m_ownerAgent->GetClass() == AIType::KNIGHT || m_ownerAgent->GetClass() == AIType::ARCHER || m_ownerAgent->GetClass() == AIType::WIZARD)
	{
		m_currState = new IdleState();
	}
	else if (m_ownerAgent->GetClass() == AIType::HEALER)
	{
		//healer has different states to other aggressive classes
		m_currState = new HealerIdleState();
	}
}

StateManager::~StateManager()
{
	//cleanup stack
}

void StateManager::Update()
{
	//check if state needs changing
	//if needs changing, call relevant end and start functions and update state
	State* before = m_currState;

	State* temp = m_currState->Update(m_ownerAgent);
	if (before != temp)
	{
		before->End(m_ownerAgent);
		//clear last state from m_currState
		delete(m_currState);
		m_currState = temp;
		m_currState->Start(m_ownerAgent);
	}
}



