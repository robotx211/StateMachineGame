///  @file IdleState.cpp
///  @brief IdleState class definition

#include <iostream>

#include "BaseState.h"
#include "IdleState.h"
#include "PursueState.h"
#include "FleeState.h"
#include "DieState.h"

#include "AIAgent.h"

/*
IDLE
in:
out:PURSUE
*/

void IdleState::Start(AIAgent *_owner)
{
	//nothing to do for start
	std::cout << "IDLE START" << std::endl;
}

State* IdleState::Update(AIAgent *_owner)
{
	//stand still state
	//starts here and also arrives here if no path is found (to player or healer

	//if health is < 50%, search for healer
	//if no path to healer found, or health > 50%, search for player
	//if no path to player found, remain idle
	
	if (_owner->GetHealthPercent() <= 0.0f)
	{
		return new DieState;
	}

	//if health < 50%
	if (_owner->GetHealthPercent() <= 50.0f)
	{
		//try to gen path to healer
		_owner->GenPathToHealer();

		if (_owner->CheckIfNoPath() == false)
		{
			return new FleeState;
		}
	}

	

	//if health > 50%
	if (_owner->GetHealthPercent() > 50.0f)
	{
		//try to gen path to player
		_owner->GenPathToPlayer();

		if (_owner->CheckIfNoPath() == false)
		{
			return new PursueState;
		}
	}

	_owner->SetTurnStatus(true);

	std::cout << "IDLE" << std::endl;
	return this;

}

void IdleState::End(AIAgent *_owner)
{
	//nothing to do for end
	std::cout << "IDLE END" << std::endl;
}