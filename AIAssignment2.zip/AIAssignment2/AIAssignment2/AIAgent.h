/// \file AIAgent.h
/// \brief AIAgent class declaration
/// \author Robert Brede

#ifndef _AI_AGENT_H_
#define _AI_AGENT_H_

#include <SDL2\SDL.h>
#include <SDL2\SDL_image.h>
#include <vector>

#include "Enums.h"
#include "PositionCoord.h"
#include "BaseState.h"
#include "Node.h"
#include "Scene.h"
#include "StateManager.h"

class ResourceManager;
class AIAgent;
class Player;
class Scene;

class AIAgent
{
private:
	AIType m_class;
	PositionCoord m_nMapPos; //world space
	PositionCoord m_screenPos; //screen space
	SDL_Texture *m_sprite;
	StateManager *m_stateMan;

	Scene *m_ownerScene;

	PositionCoord m_wayPoint; //world space
	int m_pathPosition; //waypoint in path to move to

	std::vector<Node*> m_path; //world space

	AIAgent *m_targetHealer;

	bool m_turnComplete;

	int m_health;
	int m_maxHealth;

	int m_attackDamage;
protected:
public:
	AIAgent(AIType _class, ResourceManager *_resourceMan, int _posX, int _posY, Scene *_scene);
	~AIAgent();

	//void SetSprite(SDL_Texture *_sprite);

	AIType GetClass();
	PositionCoord GetWorldPos();
	float GetHealthPercent();
	AIAgent* GetTargetHealer();

	State* GetState()
	{
		return m_stateMan->GetState();
	}

	void SetPath(std::vector<Node*> _path);

	SDL_Renderer* GetRenderer();

	void DrawAll();

	void Update();
	void Draw(SDL_Renderer *_renderer);

	void Move();

	bool CheckIfPlayerMoved();
	void GenPathToPlayer();
	bool CheckIfHealerMoved();
	void GenPathToHealer();

	void SetTurnStatus(bool _status)
	{
		m_turnComplete = _status;
	}
	bool CheckTurnStatus()
	{
		return m_turnComplete;
	}

	PositionCoord GetPlayerPos();

	bool CheckIfPathIsValid();
	bool CheckIfAtWaypoint();
	bool CheckIfNoPath();

	void AttackPlayer();

	void AddHealth(int _healAmount);

	void DealDamage(int _dmg)
	{
		m_health -= _dmg;
	}

	void HealEnemies();

	//test function
	void MinusHealth()
	{
		m_health--;
	}
};

#endif //_AI_AGENT_H_
