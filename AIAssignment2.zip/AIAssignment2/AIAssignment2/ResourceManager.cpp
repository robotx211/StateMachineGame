///  @file ResourceManager.cpp
///  @brief ResourceManager class definition

#include <SDL2\SDL.h>
#include <SDL2\SDL_image.h>
#include <iostream>

#include "ResourceManager.h"

ResourceManager::ResourceManager(SDL_Renderer *_screen)
{
	m_screen = _screen;
	
	//attempt to load sprite, if not loaded display error message
	m_knightTex = IMG_LoadTexture(m_screen, "images//knight_texture.png");
	if (m_knightTex == nullptr)
	{
		std::cout << "Knight Texture Not Loaded" << std::endl;
	}
	m_archerTex = IMG_LoadTexture(m_screen, "images//archer_texture.png");
	if (m_archerTex == nullptr)
	{
		std::cout << "Archer Texture Not Loaded" << std::endl;
	}
	m_healerTex = IMG_LoadTexture(m_screen, "images//healer_texture.png");
	if (m_healerTex == nullptr)
	{
		std::cout << "Healer Texture Not Loaded" << std::endl;
	}
	m_wizardTex = IMG_LoadTexture(m_screen, "images//wizard_texture.png");
	if (m_wizardTex == nullptr)
	{
		std::cout << "Wizard Texture Not Loaded" << std::endl;
	}
	m_playerTex = IMG_LoadTexture(m_screen, "images//player_texture.png");
	if (m_playerTex == nullptr)
	{
		std::cout << "Player Texture Not Loaded" << std::endl;
	}
}

ResourceManager::~ResourceManager()
{
	delete(m_knightTex);
	delete(m_archerTex);
	delete(m_healerTex);
	delete(m_wizardTex);
	delete(m_playerTex);
}

SDL_Texture* ResourceManager::returnSprite(AIType _type)
{
	//return relevant agent sprite
	if (_type == AIType::KNIGHT)
	{
		return m_knightTex;
	}
	else if (_type == AIType::ARCHER)
	{
		return m_archerTex;
	}
	else if (_type == AIType::HEALER)
	{
		return m_healerTex;
	}
	else if (_type == AIType::WIZARD)
	{
		return m_wizardTex;
	}

}

SDL_Texture* ResourceManager::returnPlayerSprite()
{
	//return player sprite
	return m_playerTex;
}


