///  @file AttackState.cpp
///  @brief AttackState class definition

#include <iostream>

#include "BaseState.h"
#include "AttackState.h"
#include "PursueState.h"
#include "FleeState.h"
#include "DieState.h"

#include "AIAgent.h"

/*
ATTACK
in:	PURSUE
out:PURSUE
	FLEE
	DIE
*/

void AttackState::Start(AIAgent *_owner)
{
	//nothing to do for start
	std::cout << "ATACK START" << std::endl;
}

State* AttackState::Update(AIAgent *_owner)
{
	//face towards player
		//attack player
	//if player outside attack range
		//move to pursue state
	//if health < 25%
		//move to flee state

	if (_owner->GetHealthPercent() <= 0.0f)
	{
		return new DieState;
	}

	//if health < 25%
	if (_owner->GetHealthPercent() < 25.0f)
	{
		return new FleeState;
	}

	//if player outside range
	if (std::abs(_owner->GetWorldPos().x - _owner->GetPlayerPos().x) > 1 || std::abs(_owner->GetWorldPos().y - _owner->GetPlayerPos().y) > 1)
	{
		return new PursueState;
	}

	//attack
	_owner->AttackPlayer();
	_owner->SetTurnStatus(true);

	std::cout << "ATTACK" << std::endl;
	return this;
}

void AttackState::End(AIAgent *_owner)
{
	//nothing to do for end
	std::cout << "ATACK END" << std::endl;
}