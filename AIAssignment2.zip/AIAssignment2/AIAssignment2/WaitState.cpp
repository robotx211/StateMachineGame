///  @file WaitState.cpp
///  @brief WaitState class definition

#include <iostream>

#include "BaseState.h"
#include "WaitState.h"
#include "PursueState.h"
#include "DieState.h"
#include "AIAgent.h"

/*
WAIT
in:	FLEE
out:PURSUE
	DIE
*/

void WaitState::Start(AIAgent *_owner)
{
	//nothing to do for start
	std::cout << "WAIT START" << std::endl;
}

State* WaitState::Update(AIAgent *_owner)
{
	//stand still and wait to be fully healed
	//if health is full
		//move to pursue state

	if (_owner->GetHealthPercent() <= 0.0f)
	{
		return new DieState;
	}

	if (_owner->GetHealthPercent() == 100.0f)
	{
		return new PursueState;
	}

	_owner->SetTurnStatus(true);

	std::cout << "WAIT" << std::endl;
	return this;
}

void WaitState::End(AIAgent *_owner)
{
	//nothing to do for end
	std::cout << "WAIT END" << std::endl;
}