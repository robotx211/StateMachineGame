/// \file Movement.h
/// \brief Movement function declaration
/// \author Robert Brede

#ifndef _MOVEMENT_H_
#define _MOVEMENT_H_

#include "PositionCoord.h"

PositionCoord Translate(PositionCoord _currentPos, PositionCoord _targetPos);

#endif // !_MOVEMENT_H_
