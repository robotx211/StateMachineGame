///  @file PursueState.cpp
///  @brief PursueState class definition

#include <iostream>
#include <cmath>

#include "BaseState.h"
#include "PursueState.h"
#include "AttackState.h"
#include "FleeState.h"
#include "DieState.h"
#include "IdleState.h"

#include "Node.h"
#include "AIAgent.h"
#include "Scene.h"

/*
PURSUE
in:	ATTACK
	WAIT
	IDLE
out:ATTACK
	FLEE
	DIE
*/

void PursueState::Start(AIAgent *_owner)
{
	//gen path to player
	_owner->GenPathToPlayer();

	std::cout << "PURSUE START" << std::endl;

}

State* PursueState::Update(AIAgent *_owner)
{
	//if health < 25%
		//move to flee state
	//if player in attack range
		//move to attack state
	//if path no longer valid (node on path has become an obstacle)
		//gen new path
	//else
		//move along path

	if (_owner->GetHealthPercent() <= 0.0f)
	{
		return new DieState;
	}

	//if health < 25%
	if (_owner->GetHealthPercent() <= 25.0f)
	{
		return new FleeState;
	}

	//if player in attack range
	if (std::abs(_owner->GetWorldPos().x - _owner->GetPlayerPos().x) <= 1 && std::abs(_owner->GetWorldPos().y - _owner->GetPlayerPos().y) <= 1)
	{
		return new AttackState;
	}

	//if path is no longer valid
	if (_owner->CheckIfPlayerMoved() == true)
	{
		_owner->GenPathToPlayer();
	}
	if (_owner->CheckIfPathIsValid() == false)
	{
		_owner->GenPathToPlayer();
	}

	if (_owner->CheckIfNoPath() == true)
	{
		if (_owner->GetHealthPercent() <= 50.0f)
		{
			return new FleeState;
		}
		return new IdleState;
	}

	//else
	while (_owner->CheckIfAtWaypoint() != true)
	{
		_owner->Move();
		_owner->DrawAll();
	}

	_owner->SetTurnStatus(true);

	std::cout << "PURSUE" << std::endl;
	return this;
}

void PursueState::End(AIAgent *_owner)
{
	//nothing to do for end
	std::cout << "PURSUE END" << std::endl;
}