/// \file PositionCoord.h
/// \brief PositionCoord class declaration
/// \author Robert Brede

#ifndef _POSITION_COORD_H_
#define _POSITION_COORD_H_

#include <iostream>

struct PositionCoord
{
	int x;
	int y;



	void WritePosition()
	{
		std::cout << "(" << x << "," << y << ")";
	}
};

#endif
