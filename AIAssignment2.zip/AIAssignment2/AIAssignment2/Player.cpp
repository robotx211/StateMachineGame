///  @file Player.cpp
///  @brief Player class definition

#include <SDL2\SDL.h>
#include <SDL2\SDL_image.h>

#include "Player.h"
#include "ResourceManager.h"
#include "NodeManager.h"
#include "Movement.h"

Player::Player(ResourceManager *_resourceMan, int _posX, int _posY)
{
	m_nMapPos.x = _posX;
	m_nMapPos.y = _posY;

	m_screenPos.x = _posX * 30;
	m_screenPos.y = _posY * 30;

	m_wayPoint = m_screenPos;

	m_sprite = _resourceMan->returnPlayerSprite();

	m_maxHealth = 100;
	m_health = m_maxHealth;

	m_mana = 100;
	m_maxMana = m_maxHealth;
}

Player::~Player()
{

}

PositionCoord Player::GetWorldPos()
{
	return m_nMapPos;
}

void Player::SetPosition(int _posX, int _posY)
{
	m_nMapPos.x = _posX;
	m_nMapPos.y = _posY;

	m_screenPos.x = m_nMapPos.x * 30;
	m_screenPos.y = m_nMapPos.y * 30;
}

void Player::SetWayPoint(PositionCoord _waypoint)
{
	m_wayPoint = _waypoint;
}

bool Player::CheckIfAtWaypoint()
{
	//check if at current waypoint
	if (m_screenPos.x == m_wayPoint.x * 30 && m_screenPos.y == m_wayPoint.y * 30)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void Player::Update()
{

}

void Player::Draw(SDL_Window *_window, SDL_Renderer *_renderer)
{
	//draw using sprite
	SDL_Rect temp = { m_screenPos.x, m_screenPos.y, 30, 30 };
	SDL_RenderCopy(_renderer, m_sprite, NULL, &temp);

	int windowWidth;
	int windowHeight;

	SDL_GetWindowSize(_window, &windowWidth, &windowHeight);

	//draw hud
	//draw health bar
	SDL_SetRenderDrawColor(_renderer, 0, 0, 0, 0);
	temp = { 8, windowHeight - 26, (m_maxHealth * 3) + 4, 22 };
	SDL_RenderFillRect(_renderer, &temp);

	SDL_SetRenderDrawColor(_renderer, 255, 0, 0, 0);
	temp = {10, windowHeight - 24, m_maxHealth * 3, 18 };
	SDL_RenderFillRect(_renderer, &temp);

	if (m_health > 0)
	{
		SDL_SetRenderDrawColor(_renderer, 0, 255, 0, 0);
		temp = {10, windowHeight - 24, m_health * 3, 18 };
		SDL_RenderFillRect(_renderer, &temp);
	}

	//draw mana bar
	SDL_SetRenderDrawColor(_renderer, 0, 0, 0, 0);
	temp = { windowWidth - 12 - (m_maxMana * 3), windowHeight - 26, (m_maxMana * 3) + 4, 22 };
	SDL_RenderFillRect(_renderer, &temp);

	SDL_SetRenderDrawColor(_renderer, 73, 18, 255, 0);
	temp = { windowWidth - 10 - (m_maxMana * 3), windowHeight - 24, m_maxMana * 3, 18 };
	SDL_RenderFillRect(_renderer, &temp);

	if (m_mana > 0)
	{
		SDL_SetRenderDrawColor(_renderer, 40, 135, 232, 0);
		temp = { windowWidth - 10 - (m_mana * 3), windowHeight - 24, m_mana * 3, 18 };
		SDL_RenderFillRect(_renderer, &temp);
	}
}

void Player::Move()
{
	//move towards waypoint
	PositionCoord screenSpaceWaypoint;
	screenSpaceWaypoint.x = m_wayPoint.x * 30;
	screenSpaceWaypoint.y = m_wayPoint.y * 30;

	m_screenPos = Translate(m_screenPos, screenSpaceWaypoint);

	if (m_screenPos.x == screenSpaceWaypoint.x && m_screenPos.y == screenSpaceWaypoint.y)
	{
		m_nMapPos = m_wayPoint;
	}
}

