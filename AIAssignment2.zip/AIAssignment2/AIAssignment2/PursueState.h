/// \file PursueState.h
/// \brief PursueState class declaration
/// \author Robert Brede

#ifndef _PURSUE_STATE_H_
#define _PURSUE_STATE_H_

#include <string>

#include "BaseState.h"

//chase after player
class PursueState : public State
{

private:
	std::string m_stateName = "PURSUE";
protected:
public:
	void Start(AIAgent *_owner);
	State* Update(AIAgent *_owner);
	void End(AIAgent *_owner);

	std::string GetStateName() {
		return std::string("PURSUE");
	}
};

#endif
