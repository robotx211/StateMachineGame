/// \file Scene.h
/// \brief Scene class declaration
/// \author Robert Brede

#ifndef _SCENE_H_
#define _SCENE_H_

#include <vector>
#include <SDL2\SDL.h>

#include "NodeManager.h"
#include "AIAgent.h"
#include "ResourceManager.h"
#include "Player.h"
#include "PFAlgorithms.h"

class Player;
class ResourceManager;
class AIAgent;

class Scene
{
private:
	//could make it agents vs player controlled agents rather than 1 player, 

	SDL_Window *m_window;
	SDL_Renderer *m_renderer;
	ResourceManager *m_resourceMan;

	PFAlgorithms m_pathingManager;

	std::vector<std::vector<int>> *m_mapLayout;
	std::vector<std::vector<int>> *m_agentSpawns;

	NodeManager *m_nMap;
	std::vector<AIAgent*> m_AIAgents; //should agents have turn order if turn based, so healers heal first (agents can move from waiting 1 turn faster), or last (so agents can move into healing radius 1 turn faster)
						 //should healers be static healing wells? (simplifies agents, do if short on time)
	//need instace of player
	Player *m_player;

	bool m_playerMoved; // if player moved = true, else = false

protected:
public:
	Scene();
	Scene(SDL_Window *_window, SDL_Renderer *_renderer);
	~Scene();

	void PlayerTurn();
	void EnemyTurn();

	void Draw();

	void LoadMap();

	void PlayerSelectNode();
	void PlayerAttack();

	PositionCoord GetPlayerPos();
	void DamagePlayer(int _dmg);
	void HealEnemies(PositionCoord _source, int _healing);

	SDL_Renderer* GetRenderer()
	{
		return m_renderer;
	}

	bool CheckIfPlayerMoved();
	void GenPathToPlayer(AIAgent *_start);
	bool CheckIfHealerMoved(); //returns pointer to nearest healer
	AIAgent* GenPathToNearestHealer(AIAgent *_start);

	void SetObstructions(); //sets where enemies are, so they cannot be pathed through
};

#endif
