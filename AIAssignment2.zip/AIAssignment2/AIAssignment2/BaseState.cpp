///  @file BaseState.cpp
///  @brief State class definition

#include <iostream>
#include <string>

#include "BaseState.h"
#include "StateManager.h"

/*
	Virtual Class, does nothing
*/

State::State()
{
}

State::~State()
{
}

void State::Start(AIAgent *_owner)
{
}


State* State::Update(AIAgent *_owner)
{
	//returns a pointer to the new state to change to, or returns nullptr

	std::cout << "ERROR_BASE_ERROR" << std::endl;
	return nullptr;
}

void State::End(AIAgent *_owner)
{
}