/// \file NodeManager.h
/// \brief NodeManager class declaration
/// \author Robert Brede

#ifndef _NODEMANAGER_H_
#define _NODEMANAGER_H_

#include <SDL2\SDL_ttf.h>

#include <vector>

class Node;

//class to store node map and function pertaining to the node map
class NodeManager
{
private:
	SDL_Window *m_window;
	SDL_Renderer *m_renderer;
protected:
public:

	NodeManager(int _sizeX, int _sizeY);
	~NodeManager();

	//2D vector to store the node map
	std::vector<std::vector<Node*>> m_NodeMap;

	//adds all the nodes into the nodemap, called once
	void InitNMap(int _sizeX, int _sizeY);
	//resets all values of nodes in the node map
	void ClearNMap();

	//draws all nodes in the node map on the screen
	void DrawNMap(SDL_Renderer *_renderer);

	//removes all the pathing from the node map
	void RemovePathing();

};

#endif //_NODEMANAGER_H_
