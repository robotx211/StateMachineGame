/// \file DieState.h
/// \brief DieState class declaration
/// \author Robert Brede

#ifndef _DIE_STATE_H_
#define _DIE_STATE_H_

#include <string>

#include "BaseState.h"

//die
class DieState : public State
{

private:
	std::string m_stateName = "DIE";
protected:
public:
	void Start(AIAgent *_owner);
	State* Update(AIAgent *_owner);	void End(AIAgent *_owner);

	std::string GetStateName() {
		return std::string("DIE");
	}
};

#endif
