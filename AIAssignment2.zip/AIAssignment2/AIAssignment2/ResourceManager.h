/// \file ResourceManager.h
/// \brief ResourceManager class declaration
/// \author Robert Brede

#ifndef _RESOURCE_MANAGER_H_
#define _RESOURCE_MANAGER_H_

#include <SDL2\SDL.h>
#include <SDL2\SDL_image.h>

#include "AIAgent.h"

class ResourceManager
{

private:
	SDL_Texture *m_knightTex;
	SDL_Texture *m_archerTex;
	SDL_Texture *m_healerTex;
	SDL_Texture *m_wizardTex;
	SDL_Texture *m_playerTex;

	SDL_Renderer *m_screen;
protected:
public:
	ResourceManager(SDL_Renderer *_screen);
	~ResourceManager();

	SDL_Texture* returnSprite(AIType _type);
	SDL_Texture* returnPlayerSprite();

};

#endif // _RESOURCE_MANAGER_H_
