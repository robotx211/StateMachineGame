/// \file HealerIdle.h
/// \brief HealerIdleState class declaration
/// \author Robert Brede

#ifndef _HEALER_IDLE_STATE_H_
#define _HEALER_IDLE_STATE_H_

#include <string>

#include "BaseState.h"

//stand still and wait
class HealerIdleState : public State
{

private:
	std::string m_stateName = "HEALER_IDLE";
protected:
public:
	void Start(AIAgent *_owner);
	State* Update(AIAgent *_owner);	void End(AIAgent *_owner);

	std::string GetStateName() {
		return std::string("HEALER_IDLE");
	}
};

#endif // !_HEALER_IDLE_STATE_H_
