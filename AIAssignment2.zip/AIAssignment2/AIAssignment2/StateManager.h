/// \file StateManager.h
/// \brief StateManager class declaration
/// \author Robert Brede

#ifndef _STATE_MANAGER_H_
#define _STATE_MANAGER_H_

#include <stack>

#include "Enums.h"

class AIAgent;
class State;

class StateManager
{

private:
	std::stack<State*> m_stateStack; //stack for stack based FSM
	State* m_currState; //current state for single state FSM

	AIAgent *m_ownerAgent;
protected:
public:
	StateManager(AIAgent *_owner);
	~StateManager();

	State* GetState()
	{
		return m_currState;
	}

	void Update();

};

#endif //_STATE_MANAGER_H_
