///  @file NodeManager.cpp
///  @brief NodeManager class definition

#include <vector>
#include <SDL2\SDL.h>
#include <SDL2\SDL_ttf.h>
#include <iostream>

#include "NodeManager.h"

//Additional File Includes
#include "Node.h"

//Module Contents
NodeManager::NodeManager(int _sizeX, int _sizeY)
{
	InitNMap(_sizeX, _sizeY);
}

NodeManager::~NodeManager()
{
	//deletes all nodes in nodemap, clears the nodemap and deletes the font
	for (int i = 0; m_NodeMap.begin() == m_NodeMap.end(); i++)
	{
		while (m_NodeMap.at(i).begin() != m_NodeMap.at(i).end())
		{
			delete m_NodeMap.at(i).at(0);
		}
	}

	m_NodeMap.clear();
}

void NodeManager::InitNMap(int _sizeX, int _sizeY)
{
	//fills the node map with a 30/30 grid of nodes
	for (int i = 0; i < _sizeX; i++)
	{
		std::vector<Node*> tempVec;
		for (int j = 0; j < _sizeY; j++)
		{
			tempVec.push_back(new Node({ 255,255,255,255 }, { 0,0,0,255 }, i, j, false));
		}
		m_NodeMap.push_back(tempVec);
	}
}

void NodeManager::ClearNMap()
{
	//resets values (but not positions) of all nodes in node map
	for (int i = 0; i < m_NodeMap.size(); i++)
	{
		for (int j = 0; j < m_NodeMap.size(); j++)
		{
			m_NodeMap.at(i).at(j)->ResetNode();
		}
	}
}

void NodeManager::DrawNMap(SDL_Renderer *_renderer)
{
	//draws the nodes

	//path lines can be drawn by agent, as paths they will take
	for (int i = 0; i < m_NodeMap.size(); i++)
	{
		for (int j = 0; j < m_NodeMap.at(i).size(); j++)
		{
			m_NodeMap.at(i).at(j)->DrawNode(_renderer);
		}
	}
}

void NodeManager::RemovePathing()
{
	//resets the parent nodes for each node in node map
	for (int i = 0; i < m_NodeMap.size(); i++)
	{
		for (int j = 0; j < m_NodeMap.at(i).size(); j++)
		{
			m_NodeMap.at(i).at(j)->m_parent = nullptr;
		}
	}
}